/***** 기본 데이터 *****/
const ORIGINAL_W = 2358;
const ORIGINAL_H = 5112;

/* (x1,y1,x2,y2) = 좌,상,우,하 픽셀 */
const HOTSPOT_DATA = [
  { coords:[1670,2042,1820,2192], sound:'sounds/sound1.mp3' },
  { coords:[1596,1874,1743,2021], sound:'sounds/sound2.mp3' },
  { coords:[1437,1755,1600,1918], sound:'sounds/sound3.mp3' },
  { coords:[1253,1729,1415,1891], sound:'sounds/sound4.mp3' },
];

/***** DOM 요소 *****/
const stage   = document.getElementById('stage');
const imgBg   = document.getElementById('layer1');
const imgSpin = document.getElementById('layer2');

/***** 유틸: 스케일 계산 후 핫스팟 배치 *****/
function layoutHotspots(){
  const rect = imgBg.getBoundingClientRect();
  const scaleX = rect.width  / ORIGINAL_W;
  const scaleY = rect.height / ORIGINAL_H;

  // 이미 만들어진 핫스팟 있으면 제거
  document.querySelectorAll('.hotspot').forEach(h=>h.remove());

  HOTSPOT_DATA.forEach((spot,i)=>{
    const [x1,y1,x2,y2] = spot.coords;
    const div = document.createElement('div');
    div.className = 'hotspot';
    div.style.left   = `${rect.left + x1*scaleX}px`;
    div.style.top    = `${rect.top  + y1*scaleY}px`;
    div.style.width  = `${(x2-x1)*scaleX}px`;
    div.style.height = `${(y2-y1)*scaleY}px`;

    const audio = new Audio(spot.sound);

    div.addEventListener('click', ()=>{
      /* 회전 효과 */
      imgSpin.classList.remove('rotate');
      void imgSpin.offsetWidth;          // reflow로 reset
      imgSpin.classList.add('rotate');

      /* 사운드 */
      audio.currentTime = 0;
      audio.play();
    });

    document.body.appendChild(div);      // 스테이지 밖에 두면 스케일변화에 강건
  });
}

/***** 최초 실행 & 리사이즈 대응 *****/
window.addEventListener('load', layoutHotspots);
window.addEventListener('resize', ()=>{      // 화면 돌리기 등
  // 약간의 지연 후 재계산 (리플로 방지)
  clearTimeout(window.__hsTimer);
  window.__hsTimer = setTimeout(layoutHotspots, 150);
});
